//const { response } = require("express");

let userid = null
            // 从 localStorage 中读取 userid
            userid = localStorage.getItem('userid');
            // 根据需要处理或显示 userid
            console.log(userid);

            let flag = false;
            let session_id=null
            const resLog = document.querySelector("#res-log");
            //reslog.inner.HTML
            const historyContent = document.getElementById('history-content');
            console.log(localStorage.getItem("chatsid"))
            historyContent.innerHTML=localStorage.getItem("chatsid")


            let count=1
            function newchat()
            {
                const chat_history = document.querySelector("#res-log").innerHTML
                let selfMsgArray = [];
                let llmMsgArray = [];
                const tempElement = document.createElement('div');
                tempElement.innerHTML = chat_history;

                tempElement.querySelectorAll('.sent').forEach(element => {
                    selfMsgArray.push(element.textContent.trim());
                });

                tempElement.querySelectorAll('.received').forEach(element => {
                    llmMsgArray.push(element.textContent.trim());
                });
                console.log("Self Messages Array:");
                console.log(selfMsgArray);
                console.log("LLM Messages Array:");
                console.log(llmMsgArray);
                const newhistory = document.createElement("div");
                const date=getdate()
                newhistory.id=session_id
                console.log(newhistory.id)
                console.log(date)
                newhistory.className = "selectbutton"
                    content = document.createElement("div")
                    new_name = document.createElement("div")
                    new_date = document.createElement("div")
                    content.className = "session_content"
                    new_name.className = "sessionname"
                    new_date.className = "sessiondate"
                    content.appendChild(new_name)
                    content.appendChild(new_date)
                    new_name.innerText = selfMsgArray[0]
                    new_date.innerText = date
                    newhistory.appendChild(content)
                    today.insertBefore(newhistory, today.firstChild);

                    const chatsid=historyContent.innerHTML
                    console.log(historyContent.innerHTML)
                    localStorage.setItem("chatsid", chatsid)

                    localStorage.setItem(session_id, chat_history)
                    localStorage.setItem("reshistory", chat_history)
                    newhistory.addEventListener("click", function(){
                        console.log(this)
                        session_id=this.id  
                        console.log(session_id)    
                        console.log(localStorage.getItem(session_id))  
                        get_liaoyianhistory(userid,session_id)

                        
                        

                });
            
        }
        async function get_liaoyianhistory(userid, session_id) {
            try {
                // 发起 fetch 请求并等待其完成
                const response = await fetch(`http://127.0.0.1:8001/chain/get_liaotian`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ userid, session_id })
                });
        
                // 检查 HTTP 响应状态
                if (!response.ok) {
                    throw new Error(`HTTP 错误! 状态: ${response.status}`);
                }
        
                // 解析 JSON 数据
                const data = await response.json();
                
                // 处理成功的响应
                if (data.success) {
                    console.log("聊天历史成功获得");
                    console.log(data.LiaotianHistory);
                    document.querySelector("#res-log").innerHTML = data.LiaotianHistory;
                } else {
                    alert(data.message);
                }
            } catch (error) {
                // 捕捉并处理错误
                console.error('错误:', error);
            }
        }
                


function getdate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = ("0" + (currentDate.getMonth() + 1)).slice(-2); // getMonth()返回0-11，需要+1，并保证两位数
    const day = ("0" + currentDate.getDate()).slice(-2); // getDate()返回1-31，保证两位数
    const formattedDate = `${year}-${month}-${day}`;
    return formattedDate
}

function sendrequest(session_id1, flag1) {
    // 通过检查 flag1 参数来确定是否需要生成新的 session_id
    if (!flag1) {
        session_id = Date.now().toString()// 使用当前时间戳作为 session_id
        flag = true// 设置 flag 为 true，表示已经生成新的 session_id
    }
    else {
        session_id = session_id1// 使用传入的 session_id1 参数作为 session_id
    }
                // console.log(session_id)
                // console.log(session_id1)
                // console.log(flag)
                // console.log(flag1)
    const text = document.querySelector("#input-chat").value; // 获取用户输入的消息文本

    // 构建请求的数据对象
    const data = {
        input:
        {
                        input: text
                    },
                    config: {
                        "configurable": {
                            "session_id": session_id,
                            "userid": userid
                        }
                    }
                };

                // 获取显示消息的容器元素
               
                const selfMsg = document.createElement("div");
                selfMsg.className = "msg-item sent";
                selfMsg.innerText = text;
                resLog.appendChild(selfMsg);// 将用户输入的消息文本添加到显示消息的容器中

                const receivedMsg = document.createElement("div");
                receivedMsg.className = "msg-item received";
                resLog.appendChild(receivedMsg);
                document.querySelector("#input-chat").value = '';// 清空输入框的内容

                // 发送 POST 请求到服务器
                fetch("http://127.0.0.1:8001/chain/stream_log", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data),
                }).then(response => {
                    if (response.ok) {
                        const reader = response.body.getReader();
                        const decoder = new TextDecoder("utf-8");
                        const res = receivedMsg;

                        //console.log(userid)

                        function read() {
                            reader.read().then(({ done, value }) => {
                                if (done) {
                                    console.log('Stream closed');

                                    fetch(`http://127.0.0.1:8001/chain/log?session_id=${session_id}&userid=${userid}`, {
                                        method: 'GET',
                                        headers: {
                                            'Content-Type': 'application/x-www-form-urlencoded',
                                        }
                                    })
                                        .then(response => {
                                            if (response.ok) {
                                                console.log('successful'); // 如果响应正常，打印'successful'到控制台
                                            } else {
                                                console.log('bug'); // 如果响应不正常，打印'bug'到控制台
                                            }
                                        })
                                        .catch(error => {
                                            console.error('Error fetching data:', error); // 打印错误到控制台
                                        });

                                    return;
                                }
                                const chunk = decoder.decode(value, { stream: true });
                                chunk.split('\r\n').forEach(eventString => {
                                    if (eventString && eventString.startsWith('data: ')) {
                                        const str = eventString.substring("data: ".length);
                                        const data = JSON.parse(str);
                                        data.ops.forEach(item => {
                                            if(item.op === "add" && item.path === "/logs/ChatZhipuAI/streamed_output_str/-"){
                                                // 将换行符转换为 <br> 标签
                                                let htmlContent = item.value
                                                htmlContent = htmlContent.replace(/###/g, '<b>'); 
                                                htmlContent = htmlContent.replace(/\r?\n/g, '<br>');
                                                res.innerHTML += htmlContent;
                                            }
                                        })
                                    }
                                });
                                read();
                            }).catch(error => {
                                console.error('Stream error', error);
                            });
                        }

                        read();
                    } else {
                        console.error('Network response was not ok.');
                    }
                }).catch(error => {
                    console.error('Fetch error:', error);
                });
                if(count==1)
                    {
                        newchat()
                    }
                    count=count+1;
            }

            const sidebar = document.getElementById('sidebar');
            const btnFold = document.getElementById('btn-fold');
            const introContent = document.querySelector('.intro');
            const teamContent = document.querySelector('.team');


            //折叠变换
            btnFold.addEventListener('click', () => {
                sidebar.classList.toggle('collapsed');
                btnFold.classList.toggle('icon-zhuomianbushu'); // 折叠图标
                btnFold.classList.toggle('icon-zhankai');  // 展开图标
                if (sidebar.classList.contains('collapsed')) {
                    newbutton.style.display = 'none'; // 当侧边栏折叠时隐藏另一个按钮
                } else {
                    newbutton.style.display = 'block'; // 当侧边栏展开时显示另一个按钮
                }
            });

            const today = document.querySelector('.today');

            //发送按钮的点击事件-调用sendrequest
            document.querySelector("#input-send").addEventListener("click", () => {
                sendrequest(session_id, flag)
            });

            // 全局 keydown 事件监听器
            document.addEventListener("keydown", (event) => {
                if (event.key === "Enter") {
                    if (event.shiftKey) {
                        // Shift + Enter for new line
                        event.preventDefault(); // Prevent the default Enter action
                        const start = inputchat.selectionStart;
                        const end = inputchat.selectionEnd;
                        inputchat.value = inputchat.value.substring(0, start) + "\n" + inputchat.value.substring(end);
                        inputchat.selectionStart = inputchat.selectionEnd = start + 1;
                    } else {
                        // Enter for sending message
                        event.preventDefault(); // Prevent the default Enter action
                        sendrequest(session_id, flag);
                    }
                }
            });


            //点击介绍按钮，历史与团队隐藏
            document.querySelector('.icon-intro').addEventListener('click', () => {
                historyContent.style.display = 'none';
                introContent.style.display = 'block';
                teamContent.style.display = 'none';
            });
            //点击历史对话按钮，介绍与团队隐藏
            document.querySelector('.icon-dialog').addEventListener('click', () => {
                historyContent.style.display = 'block';
                introContent.style.display = 'none';
                teamContent.style.display = 'none';
            });
            //点击团队按钮，介绍与对话隐藏
            document.querySelector('.icon-profile').addEventListener('click', () => {
                historyContent.style.display = 'none';
                introContent.style.display = 'none';
                teamContent.style.display = 'block';
            });


            //点击新建对话按钮
            document.querySelector("#newbutton").addEventListener("click", () => {
                flag = false
                fetch(`http://127.0.0.1:8001/chain/save_liaotian?userid=${encodeURIComponent(userid)}&session_id=${encodeURIComponent(session_id)}&liaotian_history=${encodeURIComponent(document.querySelector("#res-log").innerHTML)}`,{
                    method:'GET',
                    headers:{
                        'Content-Type': 'application/x-www-form-urlencoded',
                    }
                })
                .then(response=>response.json())
                .then(data=>{
                    console.log('Response from server:', data);
                })
                .catch(error =>{
                    console.error('Error:',error);
                });


                document.querySelector("#res-log").innerHTML=''
                const userid1= localStorage.getItem("userid"); // 从 localStorage 获取 userid


                fetch(`http://127.0.0.1:8001/chain/save_chat?userid=${encodeURIComponent(userid)}&chat_history=${encodeURIComponent(historyContent.innerHTML)}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    }
                })                  
           
                .then(response => response.json()) 
                .then(data => {
                    console.log('Response from server:', data);
                })
                .catch(error => {
                    console.error('Error:', error);
                });
                count=1;


             
            })

            

            

            