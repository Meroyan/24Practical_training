const express = require('express');
const path = require('path');
const app = express();
const bodyParser = require('body-parser');
const mysql = require('mysql');

// 创建数据库连接
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '041202',
    database: 'login'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Database connected.');
});

// 使用 body-parser 中间件解析请求体
app.use(bodyParser.urlencoded({ extended: true }));

// 提供静态文件
app.use(express.static(path.join(__dirname, 'static')));

app.use(express.json());  // 确保添加了这一行

// 登录处理端点
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM `check` WHERE username = ? AND password = ?';

    db.query(query, [username, password], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            // 成功登录，重定向到 
            // 用户名和密码匹配成功
            

               
            res.redirect('/chat.html')

         
        } else {
            // 登录失败，显示错误信息
    
            res.status(401).send('登录失败，请检查您的用户名和密码。');
        }
    });
});

app.post('/history', (req, res) => {
    console.log('请求体:', req.body);  // 打印请求体，检查参数是否存在
    const { username, password } = req.body;
    const query1 = 'SELECT chathistory FROM `check` WHERE username = ? AND password = ?';
    
    db.query(query1, [username, password], (err, chatResults) => {
        if (err) {
            console.error('数据库查询错误:', err);
            return res.status(500).json({ success: false, message: '内部服务器错误' });
        }
        console.log('查询参数:', [username, password]);
        console.log('查询结果:', chatResults);
        const chatHistory = chatResults[0] ? chatResults[0].chathistory : '';
        console.log('聊天记录:', chatHistory);  // 打印聊天记录到控制台
        res.json({
            success: true,
            chatHistory: chatHistory
        });
    });
});

// 注册处理端点
app.post('/register', (req, res) => {
    const { username, password, confirm_password } = req.body;

    // 两次密码不一致
    if (password !== confirm_password) {
        return res.status(400).send('两次输入的密码不一致，请重新输入！');
    }
    const chathistory=`<div class="history" id="history-content">
                    <h2>历史记录</h2>
                    <div class="today"></div>
                    <div class="yesterday"></div>
                    <div class="last-7days"></div>
                    <div class="last-30days"></div>
                </div>`
    // 一致，插入到数据库中
    const query = 'INSERT INTO `check` (username, password,chathistory) VALUES (?, ?,?)';

    db.query(query, [username, password,chathistory], (err, results) => {
        if (err) {
            return res.status(500).send('注册失败，请更改用户名后再试。');
        }
        // 成功注册，重定向到登陆页面
        res.redirect('/login.html');
    });
});

// 注册处理端点
app.post('/update', (req, res) => {
    const { username, password, confirm_password } = req.body;

    // 两次密码不一致
    if (password !== confirm_password) {
        return res.status(400).send('两次输入的密码不一致，请重新输入！');
    }

    // 一致，插入到数据库中
    const query = 'INSERT INTO `check` (username, password) VALUES (?, ?)';

    db.query(query, [username, password], (err, results) => {
        if (err) {
            return res.status(500).send('注册失败，请更改用户名后再试。');
        }
        // 成功注册，重定向到登陆页面
        res.redirect('/login.html');
    });
});


// 启动服务器
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
