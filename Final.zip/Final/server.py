from typing import List
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.chat_models import ChatZhipuAI
from langchain_core.prompts import MessagesPlaceholder
from langserve import add_routes
from dotenv import load_dotenv, find_dotenv
import os
from sqlalchemy import create_engine, Column, Integer, Text, Table, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from fastapi import FastAPI, Form, HTTPException


# 加载环境变量
_ = load_dotenv(find_dotenv())
os.environ.get("ZHIPUAI_API_KEY")

# 初始化模型
model = ChatZhipuAI(
    model="glm-4",
    temperature=0.5,
)


# 导入简单的输出解析器
parser = StrOutputParser()

# 从文件中读取医学数据
with open('response.txt', 'r', encoding='utf-8') as file:
    medical_data = file.read()

# 创建系统消息模板并包含医学数据
system_template = f"基于学习的医学知识客观准确的回答病人的疑问，以下是要求：\n\n{medical_data}"

# 创建提示模板
prompt_template = ChatPromptTemplate.from_messages([
    ("system",system_template),
    MessagesPlaceholder("chat_history"),
    ("user","{input}")
])

# 链接
chain = prompt_template | model | parser



#-------------------------------------------------------------与数据库进行连接-----------------------------------------------------------
# 创建数据库表
def create_session_table_if_not_exists(username, session_id, conn):
    cursor = conn.cursor()

    # 创建表格命令
    create_table_query = f"CREATE TABLE IF NOT EXISTS _{session_id} (id INT AUTO_INCREMENT PRIMARY KEY, Message TEXT);"


    # 执行创建表格命令
    cursor.execute(create_table_query)
    print(f"表格 {session_id} 创建成功")

    # 关闭游标
    cursor.close()

#---------------------------------------------------------使用LangChain-----------------------------------------------------------


# 定义对话历史存储
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

def history_to_string(history: ChatMessageHistory) -> str:
    messages = history.messages # 假设 history.messages 返回的是一个包含消息的列表
    message_strings = [message.content for message in messages]
    return "\n".join(message_strings)


# 一个字典，用于存储不同对话的消息历史
store = {}
# 根据会话 ID 获取消息历史，如果不存在则创建新的历史记录。
def get_history_langchain(session_id: str) -> BaseChatMessageHistory:
    if (session_id not in store):
        store[session_id] = ChatMessageHistory()
    return store[session_id]

# `RunnableWithMessageHistory`：一个可运行的对象，它与消息历史结合，用于处理带有历史记录的对话。
with_message_history = RunnableWithMessageHistory(
    chain,
    get_history_langchain,
    input_messages_key="input",
    history_messages_key="chat_history",
)




#--------------------------------------------------------------与前端连接---------------------------------------------------------
# FastAPI 应用
app = FastAPI(
    title="LangServe Demo",
    description="使用 LangChain 的 Runnable 接口的简单 API 服务器",
    version="0.0.1"
)

# 添加链路由
add_routes(
    app,
    with_message_history,
    path="/chain",
)
print("dsuhfk")
# 添加静态资源
app.mount("/pages", StaticFiles(directory="static"), name="pages")

# 跨域中间件
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 请求模型输入的 Pydantic 模型
class ModelRequest(BaseModel):
    database_name: str
    table_name: str
    user_text: str

# 模型响应的 Pydantic 模型
class ModelResponse(BaseModel):
    response: str


import mysql.connector
# 登录表单处理
@app.post("/chain/login")
async def login(username: str = Form(...), password: str = Form(...)):
    # 连接到 MySQL 数据库
    conn = mysql.connector.connect(
        host="localhost",  # 数据库主机地址
        user="root",  # 数据库用户名
        password="041202"  # 数据库密码
    )
    cursor = conn.cursor()
    user_id = username
    # 创建数据库命令
    db_name = f"user_{user_id}_db"
    create_db_query = f"CREATE DATABASE IF NOT EXISTS {db_name};"
    # 执行创建数据库命令
    cursor.execute(create_db_query)
    print(f"数据库 {db_name} 创建成功")
    # 关闭连接
    cursor.close()
    conn.close()
    return {"message": f"Database created for user {user_id}"}

#存储session_id的聊天记录
@app.get("/chain/save_liaotian")
def save_liaotianhistory(userid:str,session_id:str,liaotian_history:str):
    # 连接到 MySQL 数据库
    conn = mysql.connector.connect(
        host="localhost",  # 数据库主机地址
        user="root",  # 数据库用户名
        password="041202",  # 数据库密码
        database=f"user_{userid}_db"  # 数据库名称
    )
    cursor = conn.cursor()
    print('Received userid:', userid)
    print('Received sessionID:', session_id)
    print('Received liaotian history:', liaotian_history)
    
    try:
        
         # Set SQL mode
        cursor.execute("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO'")
        
        # Dynamically create the table name
        table_name = f"_{session_id}"
        
        # Use the table_name variable in the SQL query
        insert_query = f"INSERT INTO {table_name} (id, Message) VALUES (0, %s)"
        cursor.execute(insert_query, (liaotian_history,))
        
        # Set SQL mode
        cursor.execute("SET SQL_MODE = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'")
        
        print("0 was successfully executed")
        
        
        # 提交更改
        conn.commit()
        print(f"insert chat history for userID: {userid}")
    except mysql.connector.Error as e:
        print(f"An error occurred: {e}")
    finally:
        cursor.close()
        conn.close()
    
    # 返回一个响应
    return f"Chat history for userID {userid} updated successfully."

@app.post("/chain/get_liaotian")
async def get_liaotianhistory(request: Request):
    data = await request.json()  # 使用 await 正确异步获取 JSON 数据
    userid = data.get('userid')  # 使用 .get() 避免潜在的 KeyError
    session_id = data.get('session_id')
    # 连接到 MySQL 数据库
    conn = mysql.connector.connect(
        host="localhost",  # 数据库主机地址
        user="root",  # 数据库用户名
        password="041202",  # 数据库密码
        database=f"user_{userid}_db"  # 数据库名称
    )
    cursor = conn.cursor()
    print('Get userid:', userid)
    print('Get sessionID:', session_id)
    table_name = f"_{session_id}"
    select_query = f"select Message from {table_name} where id=0"
    cursor.execute(select_query)
    
    result = cursor.fetchone()  # 获取单行结果
    
    # 处理查询结果
    if result:
        LiaotianHistory = result[0]  # 从元组中提取第一列数s据
    else:
        LiaotianHistory = "No history found"  # 如果没有找到记录
    print(result[0])
    cursor.close()
    conn.close()

    return {"success": True, "LiaotianHistory": LiaotianHistory}


    
#存储左边栏页面信息
@app.get("/chain/save_chat")

def updatehistory(userid: str, chat_history: str):
    # 打印输入的参数
    
    # 连接到 MySQL 数据库
    conn = mysql.connector.connect(
        host="localhost",  # 数据库主机地址
        user="root",  # 数据库用户名
        password="041202",  # 数据库密码
        database="login"  # 数据库名称
    )
    cursor = conn.cursor()
    print('Received userID:', userid)
    print('Received chat history:', chat_history)

    try:
        # 执行 SQL 更新命令
        cursor.execute("""
            UPDATE `check`
            SET chathistory = %s
            WHERE username = %s
        """, (chat_history, userid))
        
        # 提交更改
        conn.commit()
        print(f"Updated chat history for userID: {userid}")
    except mysql.connector.Error as e:
        print(f"An error occurred: {e}")
    finally:
        cursor.close()
        conn.close()
    
    # 返回一个响应
    return f"Chat history for userID {userid} updated successfully."




from langchain.schema import HumanMessage, AIMessage
from fastapi import FastAPI, Query
@app.get("/chain/log")
def get_history(session_id:str,userid:str):
        # print(userid)
        # print(session_id)
        # 连接到 MySQL 数据库
        conn = mysql.connector.connect(
            host="localhost",  # 数据库主机地址
            user="root",  # 数据库用户名
            password="041202"  # 数据库密码
        )
        # # 获取历史记录并转换为字符串
        history = get_history_langchain(session_id)
        # 遍历历史记录
        for message in history.messages:
            if isinstance(message, HumanMessage):
                latest_human_message = message.content
            elif isinstance(message, AIMessage):
                latest_ai_message = message.content

        # 打印最新的用户消息和 AI 消息
        if latest_human_message:
            print(f"Latest User Message: {latest_human_message}")
        if latest_ai_message:
            print(f"Latest AI Message: {latest_ai_message}")

        # 创建或者连接到用户对应的数据库
        user_db_name = f"user_{userid}_db"
        conn.database = user_db_name
        # 创建或者连接到对应的会话表
        create_session_table_if_not_exists(userid, session_id, conn)
        
        # 插入历史记录字符串

        cursor = conn.cursor()
        insert_query = f"INSERT INTO _{session_id} (Message) VALUES (%s)"
        cursor.execute(insert_query, (latest_human_message,))

        insert_query = f"INSERT INTO _{session_id} (Message) VALUES (%s)"
        cursor.execute(insert_query, (latest_ai_message,))
        # process_and_save_conversation(session_id,user_input,userid)
        print("表格插入成功")
        conn.commit()
        # 关闭连接
        cursor.close()
        conn.close()
        return {"message": "History stored successfully"}


# 主程序入口
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)
